# Quick Deployment Checklist

Copy this checklist and check off items as you go!

## Pre-Deployment (5 min)

```
[ ] All files from outputs folder in one directory
[ ] GitHub account ready
[ ] Vercel account created (vercel.com)
```

## GitHub (5 min)

```
[ ] Repository created on GitHub
[ ] Code pushed to repository
[ ] Repository is accessible
[ ] Can see files on GitHub.com
```

## Vercel Setup (5 min)

```
[ ] Logged into Vercel
[ ] Connected GitHub to Vercel
[ ] Found epk-generator repository
[ ] Clicked "Import"
[ ] Added environment variable:
    Key: PLAYWRIGHT_BROWSERS_PATH
    Value: /tmp/.cache/ms-playwright
[ ] Clicked "Deploy"
```

## First Deployment (2-3 min)

```
[ ] Build started
[ ] Build completed (watch logs)
[ ] Got deployment URL
[ ] URL is: https://_________________.vercel.app
```

## Testing (5 min)

```
[ ] Site loads in browser
[ ] Filmhub colors visible (orange/black/white)
[ ] Header shows "EPK Generator"
[ ] Can click through form
[ ] Can fill in fields
[ ] Can upload test poster
[ ] Can add team member
[ ] Can click "Create EPK Project"
[ ] Validation appears
[ ] Can click "Generate EPK"
[ ] Can download HTML
[ ] Can download PDF (or see expected error)
```

## Launch (2 min)

```
[ ] Saved deployment URL
[ ] Shared URL with team
[ ] Added to bookmarks/wiki
[ ] Celebrated! 🎉
```

---

## Total Time: ~15-20 minutes

## If Something Goes Wrong

**Build fails?**
→ Check [DEPLOY_NOW.md](computer:///mnt/user-data/outputs/DEPLOY_NOW.md) troubleshooting section

**API doesn't work?**
→ Verify environment variable is set correctly

**Need help?**
→ See [DEPLOYMENT.md](computer:///mnt/user-data/outputs/DEPLOYMENT.md) for detailed guide

---

## Your Deployment Details

```
Date: ___________________
URL: ____________________
Deployed by: _____________
Status: [ ] Success [ ] Issues [ ] In Progress
```

## Common Issues & Quick Fixes

**"Module not found" during build**
```bash
cd frontend
npm install
npm run build
# If works, push to GitHub
```

**API returns 404**
```
- Check environment variable is added
- Redeploy from Vercel dashboard
```

**PDF generation times out**
```
- Expected on free tier (10s limit)
- HTML still works perfectly
- Upgrade to Pro for 60s timeout
```

---

You've got this! 🚀
