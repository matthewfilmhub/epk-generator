# Deploy to Vercel - Step-by-Step Guide

Follow these steps to get your EPK Generator live on Vercel in about 15 minutes.

## Prerequisites

✅ GitHub account
✅ Vercel account (free - sign up at vercel.com)
✅ Your project files ready

## Step 1: Prepare Your Project Structure

Your project should be organized like this:

```
epk-generator/
├── api/
│   ├── main.py
│   ├── epk_core.py
│   └── requirements.txt
├── frontend/
│   ├── src/
│   ├── public/
│   └── package.json
├── vercel.json
└── (all documentation files)
```

**Action**: Make sure all files from your outputs folder are in one directory.

## Step 2: Create GitHub Repository

### Option A: Using GitHub Desktop (Easiest)
1. Download GitHub Desktop: https://desktop.github.com
2. Open GitHub Desktop
3. Click "File" → "Add Local Repository"
4. Select your epk-generator folder
5. Click "Publish Repository"
6. Name it: `epk-generator`
7. Set to Private (recommended)
8. Click "Publish"

### Option B: Using Command Line
```bash
cd /path/to/your/epk-generator

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial commit - EPK Generator with Filmhub branding"

# Create repository on GitHub.com first, then:
git remote add origin https://github.com/YOUR-USERNAME/epk-generator.git
git branch -M main
git push -u origin main
```

**✓ Checkpoint**: Your code is now on GitHub

## Step 3: Sign Up for Vercel

1. Go to https://vercel.com
2. Click "Sign Up"
3. Choose "Continue with GitHub"
4. Authorize Vercel to access your GitHub

**✓ Checkpoint**: You're logged into Vercel

## Step 4: Import Project to Vercel

1. Click "Add New..." button (top right)
2. Select "Project"
3. Find your `epk-generator` repository
4. Click "Import"

**✓ Checkpoint**: Project selected

## Step 5: Configure Build Settings

Vercel should auto-detect the configuration from `vercel.json`, but verify:

### Framework Preset
- Should show: "Other" or auto-detected
- ✅ Leave as is

### Root Directory
- Should show: `./`
- ✅ Leave as is

### Build Command
- Should auto-detect from package.json
- ✅ Leave as is

### Output Directory
- Should show: `build` or auto-detected
- ✅ Leave as is

**✓ Checkpoint**: Settings look correct

## Step 6: Add Environment Variables

This is **CRITICAL** - the app won't work without it!

1. Click "Environment Variables" section
2. Add the following:

```
Key: PLAYWRIGHT_BROWSERS_PATH
Value: /tmp/.cache/ms-playwright
```

3. Click "Add"

**✓ Checkpoint**: Environment variable added

## Step 7: Deploy!

1. Click "Deploy" button
2. Wait 2-3 minutes for build
3. Watch the build logs (fascinating!)

You'll see:
- Installing dependencies...
- Building frontend...
- Setting up Python environment...
- Installing Playwright...
- Deploying...

**✓ Checkpoint**: Deployment in progress

## Step 8: Get Your URL

Once complete, you'll see:
- 🎉 Congratulations message
- Your live URL: `https://epk-generator-xxxx.vercel.app`
- Screenshot preview

**✓ Checkpoint**: App is live!

## Step 9: Test Your Deployment

1. Click "Visit" button or copy URL
2. You should see the EPK Generator interface
3. Test basic functionality:
   - ✅ Page loads with Filmhub colors (orange/black)
   - ✅ Can fill in film title
   - ✅ Can click through form sections

**✓ Checkpoint**: Basic UI works

## Step 10: Full Functionality Test

1. Fill in basic information:
   - Title: "Test Film"
   - Genre: "Drama"
   - Runtime: "90 minutes"
   - Logline: "A test film"
   - Synopsis: "This is a test film created to verify the EPK generator works correctly."

2. Upload a test image as poster:
   - Use any JPG/PNG from your computer
   - Recommended: 2:3 aspect ratio

3. Add contact email:
   - Your email address

4. Click "Create EPK Project"

5. Review validation results

6. Click "Generate EPK"

7. Try downloading:
   - Click "Download HTML"
   - Click "Download PDF"

**✓ Checkpoint**: Full workflow tested

## Step 11: Share With Team

Your URL is: `https://epk-generator-xxxx.vercel.app`

Share it with your team:
- Email the link
- Add to team wiki/docs
- Bookmark for easy access

**✓ Checkpoint**: Team has access

## Troubleshooting

### Build Failed

**Problem**: Deployment fails during build

**Solution**:
```bash
# Test locally first
cd frontend
npm install
npm run build

# If successful, push to GitHub:
git add .
git commit -m "Fix build"
git push
```

### API Not Working

**Problem**: Can't create projects, getting 404 errors

**Check**:
1. Vercel Dashboard → Your Project → Functions
2. Verify `api/main.py` is listed
3. Check function logs for errors
4. Verify environment variable is set

**Fix**: Redeploy
- Go to Deployments tab
- Click "..." on latest deployment
- Click "Redeploy"

### PDF Generation Fails

**Problem**: HTML works but PDF fails

**Check**:
1. Verify Playwright environment variable is set
2. Check function timeout (10s on free tier)
3. Upgrade to Pro if needed for 60s timeout

**Workaround**: HTML still works perfectly for web use

### File Upload Issues

**Problem**: Can't upload large files

**Solution**:
- Compress images before upload
- Limit stills to 8-10 (not 20+)
- Keep poster under 2MB
- Vercel has 4.5MB limit per request

## Next Steps

### Immediate (Optional)
- [ ] Add custom domain
- [ ] Enable analytics in Vercel
- [ ] Set up error notifications

### Short Term (Recommended)
- [ ] Add authentication
- [ ] Set up monitoring
- [ ] Create backup strategy

### Long Term
- [ ] Add persistent storage (S3)
- [ ] Implement user accounts
- [ ] Add team collaboration features

## Cost Monitoring

### Free Tier Includes:
- ✅ Unlimited projects
- ✅ 100 GB bandwidth/month
- ✅ 100 GB-hours functions
- ✅ SSL certificates
- ✅ Automatic deployments

### Monitor Usage:
1. Vercel Dashboard → Settings → Usage
2. Check monthly totals
3. Set up usage alerts

### When to Upgrade ($20/month):
- Need longer function timeouts (60s vs 10s)
- Exceeding bandwidth limits
- Want team features
- Need priority support

## Maintenance

### Weekly
- Check error logs in Vercel Dashboard
- Review usage metrics

### Monthly
- Update dependencies if needed
- Check for Vercel platform updates

### As Needed
- Add new features
- Fix bugs reported by team
- Scale resources based on usage

## Getting Help

### Vercel Support
- Documentation: https://vercel.com/docs
- Community: https://github.com/vercel/vercel/discussions
- Support: https://vercel.com/support

### Project Issues
- Check deployment logs
- Review function logs
- Test locally first

## Success Checklist

- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Vercel account created
- [ ] Project imported to Vercel
- [ ] Environment variable added
- [ ] First deployment successful
- [ ] URL accessible
- [ ] UI loads correctly (Filmhub colors visible)
- [ ] Can create test project
- [ ] Can generate EPK
- [ ] Can download HTML
- [ ] Can download PDF
- [ ] Team has access to URL
- [ ] Documentation shared with team

## Your Deployment Info

Fill this out for reference:

```
GitHub Repo: _______________________________________
Vercel URL: _______________________________________
Deployed On: _______________________________________
Deployed By: _______________________________________
Team Access: _______________________________________
```

---

## 🎉 Congratulations!

Your EPK Generator is now live on Vercel with Filmhub branding!

**Questions?** Check [DEPLOYMENT.md](computer:///mnt/user-data/outputs/DEPLOYMENT.md) for detailed troubleshooting.

**Next**: Share the URL with your team and start creating professional EPKs!
